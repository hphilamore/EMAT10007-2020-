num_words = None
num_unique = None 
most_common_w = None
longest = None 
shortest = None 
ave_len = None 
most_common_l = None